const { workerData, parentPort } = require('worker_threads');
const fs = require('fs');

if (!workerData) {
    console.log('Rode o arquivo "parellel.js" para executar em threads.');
    return;
}

const stream = fs.createReadStream(workerData.file, { encoding: 'utf8', start: workerData.start, end: workerData.end });
const words = [];
const uniques = new Set();
let palindromes = 0;

function palindrome(string) {
    if (string.length < 2) return false;
    const formatted = string.toLowerCase();
    const reverse = formatted.split('').reverse().join('');
    return formatted === reverse;
}

stream.on('data', data => {
    const arr = data.split(/[^A-Záàãéóíú]/ig ); // /[^A-Záàãéóíú]/ig 
    words.push(...arr);
});
stream.on('end', () => {
    const length = words.length;
    for (let i = 0; i < length; i++) {
        if (palindrome(words[i])) {
            palindromes++;
            uniques.add(words[i]);
        }
    }
    //console.log(palindromes);
    parentPort.postMessage({ palindromes, uniques });
});
