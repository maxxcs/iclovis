const fs = require('fs');
let palindromes = 0;

const initialTime = Date.now();

function palindrome(string) {
    if (string.length < 2) return false;
    const formatted = string.toLowerCase();
    const reverse = formatted.split('').reverse().join('');
    return formatted === reverse;
}

const data = fs.readFileSync('./livro.txt', { encoding: 'utf8' });
const words = data.split(/[^A-Záàãéóíú]/ig);
const length = words.length;
for (let i = 0; i < length; i++) {
    if (palindrome(words[i]))
        palindromes++;
}

console.log(`Palindromes: ${palindromes}`);
console.log(`Time: ${Date.now() - initialTime}ms`);
