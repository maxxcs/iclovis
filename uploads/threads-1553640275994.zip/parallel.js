const { Worker, isMainThread } = require('worker_threads');
const fs = require('fs');

const file = './livro.txt';
const uniques = new Set();
const numThreads = 4;
let threadsCompleted = 0;
let palindromes = 0;

const initialTime = Date.now();

function createThread(data) {
    const thread = new Worker('./thread.js', { workerData: data });
    thread.on('message', result => {
        threadsCompleted++;
        palindromes += result.palindromes;
        result.uniques.forEach(palindrome => uniques.add(palindrome));
        if (threadsCompleted === numThreads) {
            console.log(`Threads: ${numThreads}`);
            console.log(`Palindromes: ${palindromes}`);
            console.log(`Uniques: ${uniques.size}`);
            console.log(`Time: ${Date.now() - initialTime}ms`);
            //console.log(uniques);
        }
    });
}

if (isMainThread) {
    const stats = fs.statSync(file);
    const chunckSize = Math.floor(stats.size / numThreads);
    let step = 0;
    for (let i = 0; i < numThreads; i++) {
        createThread({ file, start: step, end: step + chunckSize });
        step += chunckSize;
    }
}
